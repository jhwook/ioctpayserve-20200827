

var bitcoreTasks = require('bitcore-build');

bitcoreTasks();
